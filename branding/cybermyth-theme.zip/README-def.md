a# Cybermyth Theme

Cybermyth-Theme turns your GNOME desktop into a slowly rotating globe — continents
traced out as glowing dots, spinning quietly behind your windows.

It draws straight onto the shell's background, so there's no extra window and
nothing stacked on top: just the globe, where your wallpaper used to be. Leave
it as a self-contained dark scene, or fade the background and the sphere down
until the globe floats over your own wallpaper.

## Requirements

- GNOME Shell 48 (Wayland or X11)

## Settings

Right-click the extension and open its settings, or run:

```sh
gnome-extensions prefs cybermyth-theme@cybermyth.dev
```

- **Render the globe** — on by default. Turn it off and the background stops
  being redrawn altogether, which is the setting to reach for on battery. The
  transparent top bar and the translucent menus keep working either way.
- **Theme** — the overall look. Just *Globe* today; more are on the way.
- **Background colour** — the colour of the sphere and the space around it,
  and the tint used for the top bar.
- **Background opacity** — how solid that colour is. Defaults to 0, so your
  wallpaper shows around the globe. Turn it up to cover the desktop.
- **Globe opacity** — how solid the sphere is. Defaults to 0.9. Turn it down
  to make the globe itself see-through.
- **Top bar opacity** — how solid the top bar is. It starts fully transparent,
  tinted with the background colour as you raise it. In the overview, and
  whenever a window is maximized or fullscreen on the primary monitor, the top
  bar is handed back to your shell theme so it stays readable.
- **Blur behind menus** — blurs what is underneath menus, the app grid and the
  overview.
- **Menu colour** / **Menu opacity** — the tint laid over that blur.
- **Icon highlight colour** / **Icon highlight opacity** — the colour behind an
  app grid, search or folder icon when you hover or press it.
- **Blur radius** — how far that blur reaches.
- **Rotation speed** — how fast it spins.
- **Frame rate** — redraws per second; lower it to save battery.

System menus are translucent whenever the extension is enabled; there is no
switch for that. The tint and the icon highlight are yours to set.

## About the menu blur

The blur is `Shell.BlurEffect`, applied from JavaScript — GNOME Shell's CSS has
no `backdrop-filter`, so there is no stylesheet route to it.

Menus blur whatever is genuinely underneath them, windows included. On drivers
that cannot do background blur nothing is drawn and menus are simply
translucent; there is no wallpaper stand-in.

### How the menu blur is made to work

Two things have to be right for background blur to render at all:

1. `Shell.BlurEffect` in background mode never recomputes what it sampled. It
   has to be invalidated by hand on every repaint, rate limited so a busy actor
   cannot pin the GPU.
2. `BoxPointer` paints itself into an offscreen framebuffer, and inside that
   framebuffer there is nothing behind it to sample, so the blur comes out
   empty. The redirect is switched off while the blur is attached and put back
   when it is removed.

The effect is attached to the styled content box, not to the BoxPointer, which
is larger by its arrow rise and padding.

GNOME dims the whole quick-settings BoxPointer while a submenu is open, using a
BrightnessContrastEffect it calls `dim`. That assumes an opaque menu: over a
translucent one it washes the panel out, lets the desktop show through, and
leaves light patches in the corners. The extension holds that effect off while
its own styling is applied, and restores it exactly as found.

### Optional: rounded blur corners

A blur effect always covers its actor's rectangle, so behind a rounded menu it
shows square corners. GNOME Shell offers no way to round it.

The fix is an optional system library, **gnome-rounded-blur**, which adds a
`corner-radius` property to the blur effect. This extension detects it at
startup and uses it automatically; without it everything works, the blur corners
are simply square.

It is **not bundled and cannot be**: it is a C library compiled against your
exact Mutter version and installed into `/usr` with root privileges. A prebuilt
copy would not load on a different machine, and extension packages carry no
binaries.

Debian and Ubuntu:

```sh
curl https://raw.githubusercontent.com/aunetx/blur-my-shell/refs/heads/master/scripts/rounded_blur_build.sh | bash -s -- -i
```

Arch has it on the AUR as `gnome-rounded-blur`; Fedora has a copr
(`aneagle/gnome-rounded-blur`). Source: https://github.com/kancko/gnome-rounded-blur

It links against the running Mutter, so it must be rebuilt after a GNOME Shell
update or the blur falls back to square corners.

Colours you can change are written out as a small stylesheet at runtime and
handed to St, because `:hover` and friends are pseudo-classes and cannot be set
as inline styles. It lives in the cache directory and is removed on disable.
